The ZIP file has everything you need from PRIMS, but you will need Excel 16.0 or 365 license to make it work.
Right click the zip file and check if it needs unblocking.
Download the ZIP file and extract it to wherever you want to keep PRIMS.
